=====================================================
A2 Protective Agro Care - Standalone cPanel Deployment
=====================================================

QUICK ACTIVATION INSTRUCTIONS:
1. In cPanel -> "Software" -> "Setup Node.js App":
   - Node.js version: 20.x or 22.x
   - Application mode: Production
   - Application root: a2-care (or your chosen folder name)
   - Application URL: your domain / subdomain
   - Application startup file: server.js
   - Click "Create" then click "Stop App"

2. In cPanel File Manager:
   - Go to your application root directory (/home/username/a2-care).
   - Upload this ZIP file and click "Extract".
   - Create or edit ".env" in this directory:
     (Use .env.example as a reference and update your MySQL credentials and WhatsApp number).

3. In cPanel MySQL Databases & phpMyAdmin:
   - Create your MySQL database and user.
   - In phpMyAdmin, select your database and import "database/schema.sql" (skipping CREATE DATABASE line).

4. In cPanel -> "Setup Node.js App":
   - Click "Start App" (or "Restart").
   - Visit your website!
=====================================================
