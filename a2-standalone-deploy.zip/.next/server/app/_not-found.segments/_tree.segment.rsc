:HL["/_next/static/chunks/40cn5rq_-33zo.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4180,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"1nQSmlu3V16Ixwa4LCX5b"}
