var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0a0rijj._.js")
R.c("server/chunks/src_server_repository_ts_0z3fdrn._.js")
R.c("server/chunks/_02tmj3h._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_data_0h80pr2._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_logout_route_actions_0-yq0sv.js")
R.m(39791)
module.exports=R.m(39791).exports
