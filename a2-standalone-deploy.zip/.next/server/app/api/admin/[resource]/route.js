var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/[resource]/route.js")
R.c("server/chunks/[root-of-the-server]__1s32jsc._.js")
R.c("server/chunks/src_server_repository_ts_0z3fdrn._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_024g289._.js")
R.c("server/chunks/_02tmj3h._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_[resource]_route_actions_0pfya71.js")
R.m(73180)
module.exports=R.m(73180).exports
