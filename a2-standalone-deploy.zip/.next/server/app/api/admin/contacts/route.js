var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/contacts/route.js")
R.c("server/chunks/[root-of-the-server]__0fw1y58._.js")
R.c("server/chunks/src_server_repository_ts_0z3fdrn._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_02tmj3h._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_contacts_route_actions_0r83s97.js")
R.m(62801)
module.exports=R.m(62801).exports
