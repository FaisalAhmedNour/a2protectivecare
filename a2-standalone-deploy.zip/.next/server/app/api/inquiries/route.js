var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/inquiries/route.js")
R.c("server/chunks/[root-of-the-server]__0o7jgn8._.js")
R.c("server/chunks/src_server_repository_ts_0z3fdrn._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/src_data_0h80pr2._.js")
R.c("server/chunks/_next-internal_server_app_api_inquiries_route_actions_0ppello.js")
R.m(79859)
module.exports=R.m(79859).exports
