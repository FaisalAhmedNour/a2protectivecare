:HL["/_next/static/chunks/40cn5rq_-33zo.css","style"]
:HC["/",""]
0:{"tree":{"name":"","param":null,"prefetchHints":4116,"slots":{"children":{"name":"terms","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"Zk8xJMWyvxEdfeR1CBN0_"}
