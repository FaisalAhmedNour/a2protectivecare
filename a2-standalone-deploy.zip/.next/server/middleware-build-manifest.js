globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1nQSmlu3V16Ixwa4LCX5b/_buildManifest.js",
    "static/1nQSmlu3V16Ixwa4LCX5b/_ssgManifest.js",
    "static/1nQSmlu3V16Ixwa4LCX5b/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/0i_or1e6yhdw9.js",
    "static/chunks/turbopack-3pgymf9yb62lw.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
