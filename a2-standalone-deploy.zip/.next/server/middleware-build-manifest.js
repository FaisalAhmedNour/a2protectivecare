globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Zk8xJMWyvxEdfeR1CBN0_/_buildManifest.js",
    "static/Zk8xJMWyvxEdfeR1CBN0_/_ssgManifest.js",
    "static/Zk8xJMWyvxEdfeR1CBN0_/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/0i_or1e6yhdw9.js",
    "static/chunks/turbopack-3pgymf9yb62lw.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
