module.exports=[58096,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_snapshot_route_actions_1lhogdv.js.map